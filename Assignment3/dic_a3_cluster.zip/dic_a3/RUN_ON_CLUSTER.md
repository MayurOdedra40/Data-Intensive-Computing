# Running the review pipeline on the LBD cluster

1. Upload & unzip this archive on the cluster, then `cd` into the extracted `dic_a3/` folder.
2. Start MiniStack in one terminal:   `ministack`
3. In another terminal, from this folder:   `bash src/run_cluster.sh`
   - Fetches reviews_devset.json from HDFS, provisions MiniStack (S3 buckets, DynamoDB tables,
     SSM params, 5 Lambdas + S3 triggers), loads the reviews, and writes `results.json` here.

## Resumable & restart-proof
Each run processes only the reviews not already done and saves its own snapshot to
`checkpoints/segment_NNN.json` (a background checkpointer reads DynamoDB every 30s). If anything
interrupts the run -- the driver/SSH dies OR MiniStack itself restarts -- just run
`bash src/run_cluster.sh` again: it skips the already-processed reviews (by reviewId), processes
what's left into a new segment, and `results.json` is the sum of all segments. The per-run DynamoDB
is only scratch; all durable state is the on-disk segment files.

Force a clean restart from zero:  `FORCE_FRESH=1 bash src/run_cluster.sh`

## Results
- `results.json`        -- the required final numbers (pos/neu/neg, profanityFailed, bannedUsers)
- `checkpoints/segment_*.json` -- per-run state (sentiment, per-user impolite counts, reviewIds)
- Recompute results anytime from the segments:  `python3 src/finalize_results.py`

## Tunables (env vars)
REVIEW_COUNT, BATCH_SIZE, BATCH_DELAY, CHECKPOINT_INTERVAL, MINISTACK_ENDPOINT, HDFS_DATA_PATH, FORCE_FRESH

## Integration tests (MiniStack up + run.sh applied)
cd src && pytest tests/test_integration.py tests/test_integration_edge.py -v
